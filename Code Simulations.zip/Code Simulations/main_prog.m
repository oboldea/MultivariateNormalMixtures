% This is the MATLAB code that accompanies the paper:
% 
% Boldea, O. and Magnus, J.R. (2009). "Maximum Likelihood Estimation of the 
% Multivariate Normal Mixture Model", Journal of the American Statistical 
% Association, Theory and Methods, Vol. 104, No. 488,  pp. 1539-1549.
% 
% We provide this code free of charge, and ask only that you cite the above paper.

% computes information matrix and information tests based on 1000 runs from the true
% DGP generated with the EMMIX code, which also generates estimates mu, V and prop 
% for a multivariate Gaussian mixture via Mixmod.
% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)
% Corrected degrees of freedom for the IM test on 24-03-2024

%----------------------Begin Code-----------------------------------------%
% simulate from a bivariate, two-component mixture
load 'example';
% the example above contains 1000 simulations on the true dgp of data x below, along with estimates from means and variances obtained
% from EMMIX
% number of replications
rng("default")
reps        = 1000;
% true dgp: means, variances and proportions
mu0 = [0 5; 0 5];
[m,p]       = size(mu0);
V0          = zeros(m,m,p);
V0(:,:,1)   = eye(m);
V0(:,:,2)   = [2 1; 1 2];
prop0=[0.5;0.5];
aum   = m*(m+3)/2;
aumi  = aum*p+p-1;
IMtest = zeros(reps,1);
mucheck = zeros(m,p,reps);
Vcheck= zeros(m,m,p,reps);
% sample size
n=100;
% initialize scores
scpi      = zeros(p-1,reps);
scmuvar   = zeros(aum,p,reps);
infopi    = zeros(aumi,aumi,reps);
sinfopi    = zeros(aumi,aumi,reps);
detinfopi    = zeros(reps,1);
detsinfopi   = zeros(reps,1);
stpi1         = zeros(aumi,reps);
stpi2         = zeros(aumi,reps);
stpi3         = zeros(aumi,reps);
pi            =zeros(p,reps);
% IM test significance levels and rejection frequency (size sims)
sig=[0.5;0.75;0.90;.95;.99];
nsig=size(sig,1);
df    = p*m*(m+1)*(m+2)*(m+7)/24;
crit=chi2inv(sig,df);
rejIM=zeros(nsig,reps);
% initialize the number of invertible information matrices
sreps=0;
%define covariance type in MIXMOD
% model=struct('name','','subDimensionFree',[],'subDimensionEqual',[]);
% model.name='Gaussian_pk_Lk_Ck';
for  j=1:reps
    sr=j %replication counter
    X       = x(:,:,j);
    X=X';
    prop    = mixprop(:,j);
   % get parameter estimates
    mu = means(:,:,j);
    V = vars(:,:,:,j);
    pi(:,j)=prop;
% if label switching occurs rearrange estimates
    if mu(1,1)>mu(1,2)
        prop=prop([2;1],1);
        mu = mu(:,[2;1]);
        V=V(:,:,[2;1]);
    end;
    mucheck(:,:,j)=mu;
    Vcheck(:,:,:,j)=V;
    % return scores [scpi,scmuvar] and outer product of scores [sinfopi] matrix
   [scpi(:,j),scmuvar(:,:,j), sinfopi(:,:,j)] = multscorepi(X,mu,V,prop);
   % return information matrix
    infopi(:,:,j)   = multinfopi(X,mu,V,prop);
    % check whether both matrices above are inverible
    detinfopi(j,1)  = det(infopi(:,:,j));
    detsinfopi(j,1) = det(sinfopi(:,:,j));
    if any(imag(sqrt(diag(inv(infopi(:,:,j))))))==0 & detinfopi(j,1)>0
    sreps=sreps+1;
    %standard errors of parameter estimates and their precisions
    stpi1(:,j)      = sqrt(diag(inv(infopi(:,:,j))));
    stpi2(:,j)      = sqrt(diag(inv(sinfopi(:,:,j))));
    stpi3(:,j)      = sqrt(diag(inv(infopi(:,:,j))*sinfopi(:,:,j)*inv(infopi(:,:,j))));
    IMtest(j,1) = multinfotest(X,mu,V,prop);
    rejIM(:,j)=IMtest(j,1)*ones(nsig,1)>crit;
    end;
   end;
%IM test rejection frequency
rejtest=sum(rejIM,2)/reps*100;
% get mean Monte Carlo (MC) scores
mpi    = mean(pi,2);
mscpi  = mean(scpi,2);
mmuvar = mean(scmuvar,2);
% get mean MC info matrix
mdetinfopi = sum(detinfopi,1)/sreps;
mdetsinfopi = sum(detsinfopi,1)/sreps;
mmucheck = mean(mucheck,3);
mVcheck = mean(Vcheck,4);
%standard errors of parameter estimates and their precisions
mstpi1 = sum(stpi1,2)/sreps;
mstpi2 = sum(stpi2,2)/sreps;
mstpi3 = sum(stpi3,2)/sreps;
Result=[mstpi2 mstpi1 mstpi3];


