% function multinfotest
% computes info matrix test for the m-multivariate mixture models with p Gaussian
% components
%INPUTS
% X         : mxn Gaussian random vector
% mu        : mxp mean, mx1 for each component
% V         : mxmxp variance, mxm for each component
% prop      : px1, vector of proportions
%OUTPUTS
% infotest   : scalar information matrix test

% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)

%----------------------Begin Code-----------------------------------------%
function [infotest,Sigma,rank_Sigma] = multinfotest(X,mu,V,prop);
[m,p]      = size(mu);
%dimension of the data set
n          = size(X,2);
aum        = m*(m+3)/2;
aumm       = aum*(aum+1)/2;
aummp      = aumm*p;
W         = zeros(aummp,n);
S         = zeros(aum*p+p-1,n);
[scpi, scmuvar,sinfopi] = multscorepi(X,mu,V,prop);
for t=1:n
[gt, alphat, a, bt, Bt, ct,D, Ct] = intermedpi(X(:,t),mu,V,prop);
ctt = ct';
st  = zeros(aum,aum,t);
for i=1:p
st(:,:,i) = alphat(i,1)*(ct(:,i)*ctt(i,:)-Ct(:,:,i));
W(aumm*(i-1)+1:aumm*i,t)=vech(st(:,:,i));
end
sinfa   = a*alphat;
sinfc   = ct*diag(alphat);
S(1:p-1,t)   = sinfa;
S(p:end,t)   = vec(sinfc);
end
Sigma = (W*W'-(W*S')*pinv(sinfopi)*S*W');
l = sum(W,2);
infotest=l'*pinv(Sigma)*l;
rank_Sigma = rank(pinv(Sigma));
