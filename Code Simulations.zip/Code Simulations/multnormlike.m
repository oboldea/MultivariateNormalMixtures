% function multnormlike
% computes the multivariate normal pdf of a vector given its mean
% and variance
% below, m is the dimension of the data (multivariate), p is the number
% of Gaussian mixture components
%INPUTS
% xt         : mx1 vector of random variables
% mu         : mxp mean, mx1 for each component
% V          : mxmxp variance, mxm for each component
%OUTPUT
% ft         : px1 vector with rows representing the likelihood contribution
%             of the i^th component, i = 1, ..., p
               
%----------------------Begin Code-----------------------------------------%
function ft = multnormlike(xt,mu,V);
[m,p] = size(mu);
ft   = zeros(p,1);
for i=1:p
ft(i,1) = (2*pi)^(-m/2)*(det(V(:,:,i)))^(-1/2)*exp(-0.5*(xt-mu(:,i))'*inv(V(:,:,i))*(xt-mu(:,i)));
end;
%----------------------End Code-------------------------------------------%