% function intermedpi
% computes intermediary quantities, useful in computing the score and Hessian
% of the multivariate Gaussian mixture wrt pi, for observation t and component i
% see Magnus and Boldea (2008)
% below, m is the dimension of the data (multivariate), p is the number
% of Gaussian mixture components
%INPUTS
% xt        : mx1 Gaussian random vector
% mu        : mxp mean, mx1 for each component
% V         : mxmxp variance, mxm for each component
% prop      : px1, vector of proportions
%OUTPUTS
% gt        : px1 likelihood with elements pi_i* ft(xt)
%             for ft, see multnormlike.m
% alphat    : px1 weights, see Magnus and Boldea (2008)
% a         :(p-1)xp, scores wrt phi
% bt        : mxp, each col is V_i^{-1}*(xt-mu_i)
% Bt        : mxmxp, Bt(:,:,i) =  V_i^{-1}-bit*bit'
% ct        : [m(m+3)/2]xp , see Magnus and Boldea (2008)
% D         : duplication matrix of dim m, see Magnus and Neudecker (1999)
% At        : (p-1)x(p-1)xp
% Ct        : m(m+3)/2 x m(m+3)/2 x p, see Magnus and Boldea (2008) 
% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)

%----------------------Begin Code-----------------------------------------%
function [gt, alphat, at, bt, Bt, ct,D, Ct] = intermedpi(xt,mu,V,prop);
[m,p]=size(mu);
gt     = prop.*multnormlike(xt,mu,V);
alphat = gt./sum(gt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
at     = [diag(ones(p-1,1)./prop(1:end-1,1)) -ones(p-1,1)/prop(p,1)];
bt     = zeros(m,p);
Bt     = zeros(m,m,p);
aum    = m*(m+3)/2;  
ct     = zeros(aum,p);
D      = duplication(m);
At     = zeros(p-1,p-1,p);
Ct     = zeros(aum,aum,p);
for i=1:p
    inverV      = inv(V(:,:,i));
    bt(:,i)     = inverV*(xt-mu(:,i));
    Bt(:,:,i)   = inverV-bt(:,i)*bt(:,i)';
    ct(:,i)     = [bt(:,i); -0.5*D'*vec(Bt(:,:,i))];
    St          = (kron(bt(:,i)',inverV))*D;
    Ct(:,:,i)   = [inverV St; St' 0.5*D'*(kron(inverV-2*Bt(:,:,i),inverV))*D];
end;
%---------------------------End Code--------------------------------------%
s=1;

