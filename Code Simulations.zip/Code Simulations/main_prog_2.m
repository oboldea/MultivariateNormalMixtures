% This is the MATLAB code that accompanies the paper:
% 
% Boldea, O. and Magnus, J.R. (2009). "Maximum Likelihood Estimation of the 
% Multivariate Normal Mixture Model", Journal of the American Statistical 
% Association, Theory and Methods, Vol. 104, No. 488,  pp. 1539-1549.
% 
% We provide this code free of charge, and ask only that you cite the above paper.

% computes information matrix and information tests based on 1000 runs from the true
% DGP generated with the EMMIX code, which also generates estimates mu, V and prop 
% for a multivariate Gaussian mixture via Mixmod.
% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)

% it was corrected on 21-3-2024 to correct the degrees of freedom in the
% information matrix test, see paper "Correction: Maximum Likelihood Estimation
% of the Multivariate Normal Mixture Model"

%----------------------Begin Code-----------------------------------------%
% simulate from a bivariate, two-component mixture
% DGP
rng(1);
m=2;
g=2;
n=100;
% number of replications
reps        = 10000;
% true dgp: means, variances and proportions
mu0 = [0 5; 0 5];
[m,g]       = size(mu0);
V0          = zeros(m,m,g);
V0(:,:,1)   = eye(m);
V0(:,:,2)   = [2 1; 1 2];
prop0=[0.5;0.5];
% generate gaussian mixture
x = zeros(n,m,reps);
for r=1:reps
    gm =gmdistribution(mu0',V0,prop0);
x(:,:,r) = random(gm,n);
end
aum   = m*(m+3)/2;
aumi  = aum*g+g-1;
IMtest = zeros(reps,1);
mucheck = zeros(m,g,reps);
Vcheck= zeros(m,m,g,reps);
% initialize 
scpi      = zeros(g-1,reps);
scmuvar   = zeros(aum,g,reps);
infopi    = zeros(aumi,aumi,reps);
sinfopi    = zeros(aumi,aumi,reps);
detinfopi    = zeros(reps,1);
detsinfopi   = zeros(reps,1);
stpi1         = zeros(aumi,reps);
stpi2         = zeros(aumi,reps);
stpi3         = zeros(aumi,reps);
pi            =zeros(g,reps);
% IM test significance levels and rejection frequency (size sims)
sig=[0.5;0.75;0.90;.95;.99];
nsig=size(sig,1);
df=g*m*(m+1)*(m+2)*(m+7)/24; % Correction to JASA, correct degrees of freedom
crit=chi2inv(sig,df);
rejIM=zeros(nsig,reps);
Sigma = zeros(g*aum*(aum+1)/2,g*aum*(aum+1)/2);
discrep =zeros(reps,1); % check numerically Enrique's df

% initialize the number of invertible information matrices
sreps=0;
for  j=1:reps
    sr=j %replication counter
    X       = x(:,:,j);
    % get parameter estimates
   GMModel = fitgmdist(X,g);
    mu  = (GMModel.mu)';
    V   = GMModel.Sigma;
    prop= (GMModel.ComponentProportion)';
   % if label switching occurs rearrange estimates
    if mu(1,1)>mu(1,2)
        prop=prop([2;1],1);
        mu = mu(:,[2;1]);
        V=V(:,:,[2;1]);
    end
    mucheck(:,:,j)=mu;
    Vcheck(:,:,:,j)=V;
    pi(:,j) = prop;
    % return scores [scpi,scmuvar] and outer product of scores [sinfopi] matrix
    X=X';
   [scpi(:,j),scmuvar(:,:,j), sinfopi(:,:,j)] = multscorepi(X,mu,V,prop);
   % return information matrix
    infopi(:,:,j)   = multinfopi(X,mu,V,prop);
    % check whether both matrices above are inverible
    detinfopi(j,1)  = det(infopi(:,:,j));
    detsinfopi(j,1) = det(sinfopi(:,:,j));
    if any(imag(sqrt(diag(inv(infopi(:,:,j))))))==0 & detinfopi(j,1)>0
    sreps=sreps+1;
    %standard errors of parameter estimates and their precisions
    stpi1(:,j)      = sqrt(diag(inv(infopi(:,:,j))));
    stpi2(:,j)      = sqrt(diag(inv(sinfopi(:,:,j))));
    stpi3(:,j)      = sqrt(diag(inv(infopi(:,:,j))*sinfopi(:,:,j)*inv(infopi(:,:,j))));
    [IMtest(j,1), Sigma(:,:,j),rank_Sigma] = multinfotest(X,mu,V,prop);
    rejIM(:,j)=IMtest(j,1)*ones(nsig,1)>crit;
    discrep(j,1)= rank(Sigma(:,:,j),1e-10)-df; % check if rank Sigma coincides with df
    end
end
%IM test rejection frequency
rejtest=sum(rejIM,2)/reps
discr = mean(discrep,1)
% get mean Monte Carlo (MC) scores
mpi    = mean(pi,2);
mscpi  = mean(scpi,2);
mmuvar = mean(scmuvar,2);
% get mean MC info matrix
mdetinfopi = sum(detinfopi,1)/sreps;
mdetsinfopi = sum(detsinfopi,1)/sreps;
mmucheck = mean(mucheck,3);
mVcheck = mean(Vcheck,4);
%standard errors of parameter estimates and their precisions
mstpi1 = sum(stpi1,2)/sreps;
mstpi2 = sum(stpi2,2)/sreps;
mstpi3 = sum(stpi3,2)/sreps;
Result=[mstpi2 mstpi1 mstpi3];


