% function multscorepi
% computes scores of the m-multivariate mixture models with p Gaussian
% components, with derivation wrt to proportions pi
%INPUTS
% X         : mxn Gaussian random vector
% mu        : mxp mean, mx1 for each component
% V         : mxmxp variance, mxm for each component
% prop      : px1, vector of proportions
%OUTPUTS
% scpi     : (p-1)x1 scores wrt phi
% scmuvar   : [m(m+3)/2]xp scores wrt theta=[mu,vech(V)]
% sinfopi  : [m(m+3)/2]xp+p-1 diagonal info matrix outer product of scores
% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)

%----------------------Begin Code-----------------------------------------%
function [scpi, scmuvar,sinfopi] = multscorepi(X,mu,V,prop);
[m,p]   = size(mu);
%dimension of the data set
n       = size(X,2);
scpi   = zeros(p-1,1);
aum     = m*(m+3)/2;
scmuvar = zeros(aum,p);
sinfopi   = zeros(aum*p+p-1,aum*p+p-1);
for t=1:n
[gt, alphat, a, bt, Bt, ct, D, Ct] = intermedpi(X(:,t),mu,V,prop);
sinfa   = a*alphat;
sinfc   = ct*diag(alphat);
scpi   = scpi+ sinfa;
scmuvar = scmuvar+sinfc;
vecsinfc = vec(sinfc);
sinfopi   = sinfopi-[sinfa*sinfa' sinfa*vecsinfc';vecsinfc*sinfa' vecsinfc*vecsinfc'];
end;
% scpi=scpi/n;
% scmuvar=scmuvar/n;
sinfopi=-sinfopi;

