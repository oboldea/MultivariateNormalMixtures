% function multinfopi
% computes info matrix of the m-multivariate mixture models with p Gaussian
% components
%INPUTS
% X         : mxn Gaussian random vector
% mu        : mxp mean, mx1 for each component
% V         : mxmxp variance, mxm for each component
% prop      : px1, vector of proportions
%OUTPUTS
% infopi   : [0.5p(m+1)(m+2)-1] x [0.5p(m+1)(m+2)-1]
%             information matrix 

% code uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu)

%----------------------Begin Code-----------------------------------------%
function infopi = multinfopi(X,mu,V,prop);
[m,p]      = size(mu);
%dimension of the data set
n          = size(X,2);
aum        = m*(m+3)/2;
Qpi2   = zeros(p-1,p-1);
Qpitheta    = zeros(p-1,aum*p);
Qtheta2  = zeros(aum*p,aum*p);
for t=1:n
[gt, alphat, a, bt, Bt, ct,D, Ct] = intermedpi(X(:,t),mu,V,prop);
atbar = a*alphat;
st  = (a-kron(atbar,ones(1,p)))*diag(alphat);
ctt = ct';
sct = ct*diag(alphat);
for i=1:p
Qpitheta(:,aum*(i-1)+1:aum*i)=Qpitheta(:,aum*(i-1)+1:aum*i)+st(:,i)*ctt(i,:);
Qtheta2(aum*(i-1)+1:aum*i,aum*(i-1)+1:aum*i) = Qtheta2(aum*(i-1)+1:aum*i,aum*(i-1)+1:aum*i)-alphat(i,1)*(Ct(:,:,i)-(1-alphat(i,1))*ct(:,i)*ctt(i,:));
for j=1:p
    if i~=j
Qtheta2(aum*(i-1)+1:aum*i,aum*(j-1)+1:aum*j) = Qtheta2(aum*(i-1)+1:aum*i,aum*(j-1)+1:aum*j) - sct(:,i)*sct(:,j)';   
    end;
end;
Qpi2=Qpi2-atbar*atbar';
end;
end;
infopi = -[Qpi2 Qpitheta; Qpitheta' Qtheta2];
