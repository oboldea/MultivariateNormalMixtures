This is the MATLAB code that accompanies the paper:

Boldea, O. and Magnus, J.R. (2009). "Maximum Likelihood Estimation of the 
Multivariate Normal Mixture Model", Journal of the American Statistical 
Association, Theory and Methods, Vol. 104, No. 488,  pp. 1539-1549.

We provide this code free of charge, and ask only that you cite the above paper.

The code is estimating parameters and their precisions for the IRIS dataset via 
the MATLAB module MIXMOD 2.1.1. The dataset is contained in iris.dat.

The code should be run from main_prog_app.m, which calls functions:

1. multnormlike-> computes multivariate normal likelihood
2. intermedpi  -> performs some intermediate calculations
3. multscorepi -> calculates scores for proportions, means and variances, as well as the matrix 
                  of the outer product of scores
4. multinfopi  -> computes the information matrix based on analytical Hessian, proposed
                  in paper above
5. multinfotest -> computes the information matrix test

The rest of the functions either pertain to the MIXMOD program or are borrowed
from matrix operation codes provided free of charge on the web by Thomas Minka.