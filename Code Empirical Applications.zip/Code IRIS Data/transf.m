% function transf
% rewrites p proportions prop into (p-1)x1 vector phi
% as in Magnus and Boldea (2008)
% INPUTS
% prop          : px1 mixture proportions
% OUTPUTS
% phi           : (p-1)x1 elements phi
%--------------------Begin Code------------------------------------------%
function phi=transf(prop)
p=size(prop,1);
sqprop=sqrt(prop);
if p==1
    phi=2*pi;
elseif p==2
    phi=acos(sqprop(1,1));
else
phi=[acos(sqprop(1,1)) ;zeros(p-2,1)];
end;
if p<=2 return;
else
     for i=2:p-1
     phi(i,1)= acos(sqprop(i,1)/abs(sin(phi(i-1,1))));
     end;       
end;
% elseif p==3
%     phi(2,1)=acos(sqprop(2,1)/abs(sin(phi(1,1))));
% elseif p==4
%     phi(2,1)=acos(sqprop(2,1)/abs(sin(phi(1,1))));
%     phi(3,1)=acos(sqprop(3,1)/abs(sin(phi(1,1))*sin(phi(2,1))));
% end;   

