% This is the MATLAB code that accompanies the paper:
% 
% Boldea, O. and Magnus, J.R. (2009). "Maximum Likelihood Estimation of the 
% Multivariate Normal Mixture Model", Journal of the American Statistical 
% Association, Theory and Methods, Vol. 104, No. 488,  pp. 1539-1549.
% 
% We provide this code free of charge, and ask only that you cite the above paper.

% This code computes the information matrix and the information matrix test
% for the well-known IRIS data set, which is described in the paper above

% computes estimates mu, V and prop for a multivariate Gaussian mixture via the
% program Mixmod 2.1 : http://www.mixmod.org/download.php
% you have to add this program to your MATLAB path

% uses vec.m, vech.m and duplication.m from Thomas P. Minka,
% (tpminka@media.mit.edu) 

%----------------------Begin Code-----------------------------------------%

X       = load('iris.dat');
X=X(:,1:4);
[n,m]   = size(X);
p       = 3;
out     = mixmod(X,p);
X=X';
prop    = out.modelOutput(1).param.proportion;
prop=prop';
mu      = zeros(p,m);
V       = zeros(m,m,p);
for i=1:p
mu(i,:) = out.modelOutput(1).param.mean{i};
V(:,:,i)= out.modelOutput(1).param.dispersion{i};
end;
mu = mu';
% below are, for comparison, estimation results for means and variances
% from the program EMMIX of Geoffrey McLachlan
% http://www.maths.uq.edu.au/~gjm/
% prop = [0.333;0.367;0.299];
% V=zeros(m,m,p);
% mu   = [ 5.0060       3.4280       1.4620      0.24600; ...   
%      6.5445       2.9487       5.4796       1.9846; ...    
%      5.9150       2.7778       4.2016       1.2970]';
% V(:,:,1)   =   [ 0.121764 0 0 0;...    
%        0.972320E-01  0.140816 0 0;...    
%        0.160280E-01  0.114640E-01  0.295560E-01 0;...
%        0.101240E-01  0.911200E-02  0.594800E-02  0.108840E-01];
% V(:,:,2) =  [0.387044 0 0 0;...   
%        0.922079E-01  0.110338 0 0; ...   
%        0.302812      0.842876E-01  0.327797 0;...
%        0.616510E-01  0.560115E-01  0.745300E-01  0.857977E-01];
% V(:,:,3) = [0.275319 0 0 0;...   
%        0.969414E-01  0.926460E-01 0 0;...
%        0.184662      0.911432E-01  0.200630 0;...   
%        0.543907E-01  0.429973E-01  0.609785E-01  0.319970E-01]; 
% for i=1:p
% V(:,:,i) = V(:,:,i)+V(:,:,i)'-diag(diag(V(:,:,i)));
% end;
%calculate scores and their outer product
% score is [scpi, scmuvar] and outerproduct of scores is sinfopi
[scpi,scmuvar,sinfopi] = multscorepi(X,mu,V,prop);
% calculate information matrix based on analytical formula in Boldea and
% Magnus (2009)
infopi = multinfopi(X,mu,V,prop);
%perform information matrix test proposed in Boldea and Magnus (2009)
infotest=multinfotest(X,mu,V,prop);
